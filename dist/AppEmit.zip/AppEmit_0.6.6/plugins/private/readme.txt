private plugins

auth user can add plugins here.