﻿AppEmit  v1.3.10

连接本地程序和webkit内核浏览器互相通信的易扩展的中间件。

需要开机自启动，加入杀毒程序的白名单
如使用局域网或所有用户功能，第一次最好管理员身份安装

有问题联系
web:http://www.appemit.com
email:appemit@appemi.com
qq: 273315156
