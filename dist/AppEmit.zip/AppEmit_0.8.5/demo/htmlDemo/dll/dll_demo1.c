	#include <windows.h>
	// 开发可以互动信息的动态链接库 Dll 
	// 下载最新版本tcc    (gcc未测试)
	// 更多信息 http://www.appemit.com
	//  编辑为 dll_demo1.dll 
	////生成DLL 必须使用最新版tcc扩展库才能支持UTF8,UTF16字符串
	/*
	入口函数,该函数可以有也可以没有。
	
	入口函数会自动加锁以保证线性调用,要避免在DllMain内调用下列函数:
	1、调用LoadLibrary或其他可能加载DLL的API函数( CreateProcess等 )
	2、可能再次触发DllMain的函数,例如 CreateThread,ExitThread
	3、GetModuleFileName, GetModuleHandle 等其他可能触发系统锁的API函数
	总之在DllMain最好不要调用API函数.
	*/
	
	/*
	 主要是4个函数接口,App开头的函数和变量名称不要改变
	 AppDll_init    dll初始化，用户输入参数 认证
	 AppDll_loaded  dll启动后执行
	 AppDll_destroy   dll 退出前执行
	 AppDll_OnMsg    互动时 接收 反馈 消息
	*/
	char *mycid ="10000-0";
	char *clsId="50FCF891-1B93-4AE5-8A66-AB26A3C03378";  // 
	int dllThid;
      //定义一个结构体
	 typedef  struct Msg{char * msg;int dllThid; const char *cid; const char * sid;int rid; } ;
	
	char* joinStr(char *s1, char *s2, char *s3)
	{
    	char *result = malloc(strlen(s1)+strlen(s2)+strlen(s3)+1);//+1 for the zero-terminator
    	if (result == NULL) exit (1);
    	strcpy(result, s1);
    	strcat(result, s2);
    	strcat(result, s3);
    	return result;
	}
   
	int __stdcall DllMain(void * hinstDLL, unsigned long fdwReason, void * lpvReserved) {
	
		if (fdwReason == 1/*DLL_PROCESS_ATTACH*/ ){ 
			
		}
		return 1;
	}
	//__declspec(dllexport) 声明导出函数 
	__declspec(dllexport) int AppDll_OnMsg(HWND hwnd, char *cid, char *sid,int rid,char *Json) 
	{     
 
		struct Msg callBackMsg = { 
			.msg =Json, 
			.dllThid = dllThid, 
			.cid=mycid ,
			.sid= sid ,
			.rid=rid,
			 
		};
	 
	 	/*
		_WM_THREAD_CALLBACK 使所有回调安全的转发到UI线程。
		_WM_THREAD_CALLBACK 可以跨线程跨语言并且不需要创建回调线程,适用任何普通winform对象。
		
		与其他回调方案的比较：
    	raw.tocdecl raw.tostdcall 不能跨线程使用, 
    	thread.tocdecl,thread.tostdcall 需要创建回调线程。
    	thread.command 则只能在aardio代码中使用,需要将窗体转换为thread.command对象。
    	*/
 
		SendMessage(
			hwnd,0xACCE , 
			"AppOnMsg({string msg;int dllThid;string cid; string sid; int rid })", //要调用的窗体函数名( 结构体原型声明 ); 结构体原型声明应使用AE语法
			&callBackMsg //将前面定义的结构体作为调用参数
		);
  
		return 0;
	}
 
	__declspec(dllexport) int AppDll_init(HWND hwnd, char *cid, char *sid,int rid,char *Json) 
	{     
      //判断cid sid Json里面的AppAuth 
        dllThid = GetCurrentThreadId();
        //自行设置 验证来源是否正确
        //必须msg反馈 'AppStep', 'clsId' 'AppAuth'。AppAuth为true  clsId一致 才继续
        // 支持\" 或者 '  如果有data，只发送data到浏览器websock接收
        char *msg = joinStr(joinStr("{'data':{'code':200,'cid':'10000-1','sid':'123','rid':-1,'rec':",Json,",'AppStep':'init'},'AppStep':'init','AppAuth':true,'clsId':'"),clsId,"'}");
      
        AppDll_OnMsg(hwnd,cid,sid,rid,msg);
 
		return 0;
	}
	__declspec(dllexport) int AppDll_loaded(HWND hwnd, char *cid, char *sid,int rid,char *Json) 
	{     
      //处理业务 //必须msg反馈  'clsId'.如果有data，只发送data到浏览器websock接收
        char *msg = joinStr(joinStr("{'data':{'code':200,'cid':'10000-1','sid':'123','rid':-1,'rec':",Json,",'AppStep':'loaded'},'AppStep':'loaded','clsId':'"),clsId,"'}");
         AppDll_OnMsg(hwnd,cid,sid,rid,msg);
 
		return 0;
	}
	__declspec(dllexport) int AppDll_destroy(HWND hwnd, char *cid, char *sid,int rid,char *Json) 
	{     
      //处理业务必须msg反馈 'clsId' .如果有data，只发送data到浏览器websock接收
         char *msg = joinStr(joinStr("{'data':{'code':200,'cid':'10000-1','sid':'123','rid':-1,'rec':",Json,",'AppStep':'destroy'},'AppStep':'destroy','clsId':'"),clsId,"'}");
        AppDll_OnMsg(hwnd,cid,sid,rid,msg);
 
		return 0;
	}
 	//测试
	__declspec(dllexport) int Add(int a, int b ) 
	{     
		return a+b;
	} 